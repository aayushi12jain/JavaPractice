package com.uhcl.eservice;

public interface DataInterface {
	public UserProfile login(String name, String pswd);

}
