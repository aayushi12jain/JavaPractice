package com.uhcl.eservice;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateClass implements DataInterface{

	protected SessionFactory sessionFactory;
	
	public void setup()
	{
		final StandardServiceRegistry reg = new StandardServiceRegistryBuilder().configure().build();
		try
		{
			sessionFactory = new MetadataSources(reg).buildMetadata().buildSessionFactory();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			StandardServiceRegistryBuilder.destroy(reg);
		}
	}
	
	public void exit()
	{
		sessionFactory.close();
	}

	@Override
	public UserProfile login(String name, String pswd) {
		// TODO Auto-generated method stub
		setup();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		UserProfile u = session.get(UserProfile.class,name);
		session.getTransaction().commit();
		
		if(u==null) {
			System.out.println("Your login ID is not found!");
			session.close();
			exit();
			return null;
		}else {
			if(pswd.equals(u.getPswd())) {
				System.out.println("You are logged in successfully! ^-^ ");
				session.close();
				exit();
				return null;
			}else {
				System.out.println("Your login password is wrong!");
				session.close();
				exit();
				return null;
			}
		}
	}

}
