package com.uhcl.eservice;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
	static DataInterface d = new HibernateClass();
    public static void main( String[] args )
    {
        Scanner sc = new Scanner(System.in);
        int select = -1;
        while(select!=0) {
        	System.out.println("Please make a selection:");
        	System.out.println("0: Time for tea!");
        	System.out.println("1: Login into eServices");
        	System.out.println("2: Login into Balck Board");
        	
        	select = sc.nextInt();
        	System.out.println();
        	
        	if(select==1) {
        		System.out.println("Taking to the Eservice Login Window!");
        		new EserviceLogin().login(d);
        	}else if(select == 2) {
        		System.out.println("Taking to the Black Board Login Window!");
        	}else if(select!=0){
        		System.out.println("Wrong choice! Try Again!");
        	}
        }
    }
}
