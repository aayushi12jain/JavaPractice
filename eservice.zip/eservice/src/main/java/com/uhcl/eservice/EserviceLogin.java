package com.uhcl.eservice;

import java.util.Scanner;

public class EserviceLogin {

	Scanner input = new Scanner(System.in);
	public void login(DataInterface d) {
		System.out.println("Please enter your id: ");
		String id = input.nextLine();
		System.out.println("Please enter your password: ");
		String password = input.nextLine();
		UserProfile user = d.login(id, password);	
	}
}
