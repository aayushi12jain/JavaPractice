package com.uhcl.eservice;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="userProfile")
public class UserProfile {
	
	@Id
	@Column(name="userId")
	private int userId;
	
	@Column(name="userName")
	private String name;
	
	@Column(name="userPassword")
	private String pswd;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="email")
	private String email;
	
	@Column(name="phoneNumber")
	private String phoneNumber;
	
	@Column(name="college")
	private String college;
	
	@Column(name="userType")
	private String userType;
	
	@Column(name="dateOfJoining")
	private DateAndTime dateOfJoining;
	
	public UserProfile() {
		
	}
	
	public UserProfile(String name, String pswd, String gender, String email, String phoneNumber,
			String college, String userType, DateAndTime dateOfJoining) {
		super();
		this.name = name;
		this.pswd = pswd;
		this.gender = gender;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.college = college;
		this.userType = userType;
		this.dateOfJoining = dateOfJoining;
	}

	public UserProfile(int userId, String name, String pswd, String gender, String email, String phoneNumber,
			String college, String userType, DateAndTime dateOfJoining) {
		super();
		this.userId = userId;
		this.name = name;
		this.pswd = pswd;
		this.gender = gender;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.college = college;
		this.userType = userType;
		this.dateOfJoining = dateOfJoining;
	}

	public int getUserId() {
		return userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPswd() {
		return pswd;
	}

	public void setPswd(String pswd) {
		this.pswd = pswd;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public DateAndTime getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(DateAndTime dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	
	
}
