



create table userProfile (
    userId int primary key identity(202501,1),
    userName varchar(15),
    userPassword varchar(15),
    gender varchar(10),
    email varchar(30),
    phoneNumber varchar(12),
    college varchar(30),
    userType varchar(10),
    dateOfJoining DATETIME2 DEFAULT SYSDATETIME()
);


insert into userProfile VALUES(
    'Lin',
    'Lin123!!',
    'Male',
    'lin123@data.com',
    '343-434-0063',
    'COB',
    'Faculty',
    SYSDATETIME()
);


select * from userProfile;

create table studentProfile (
    userId int primary key FOREIGN KEY REFERENCES userProfile(userId),
    major varchar(15),
    GPA int,
    credits int,
    visaStatus varchar(5)
);

select * from studentProfile;

insert into studentProfile values(
    '202501',
    'MIS',
    4.0,
    30,
    'F1'
);

create table course(
    courseId varchar(10) primary key,
    courseName varchar(30),
    studentEnrolled int,
    capacity int,
    isAvailable varchar(10),
    prof int FOREIGN KEY REFERENCES userProfile(userId),
    major varchar(15)
);



insert into course values(
    'MIS3456',
    'Management Information System',
    0,
    30,
    'Available',
    202502,
    'MIS'
);
select * from course;

create table notes(
    noteId int PRIMARY KEY IDENTITY(101,1),
    courseId varchar(10) FOREIGN KEY REFERENCES course(courseId),
    content varchar(100),
    dateOfPosting DATETIME2 DEFAULT SYSDATETIME(),
    postedBy int FOREIGN KEY REFERENCES userProfile(userId)
)

insert into notes values(
    'MIS3456',
    'The course syllabus has been shared on mails. Thanks!',
    SYSDATETIME(),
    202502
);

select * from notes;